print("Hello, this is Luke Rowberry's programmer portfolio!")
input("\nPress Enter to continue...")

print("""\n\nI have experience in programming languages in Python, HTML, Java, and Lua,
however this portfolio will be comprised of what I can do in the Python language.""")
input("\nPress Enter to continue...")

print("""\n\nI enjoy programming and like to code whenever I am struck with inspiration.
It is frustrating to spend so much time skimming through my code over and over again
because I forgot to add a period somewhere. However, I find it extremely satisfying
when I get my code to work and watch my lines of code turn into something interesting
and is the only reason I still code today.""")
input("\nPress Enter to continue...")

print("""\n\nThe projects in this folder include:
1-Test Taking System
2-Shmup
3-Tkinter Layouts
4-Login System
5-Tic-Tac-Toe""")
input("\nPress Enter to continue...")

print("""\n\nThe "Test Taking System" uses Pythons ability to open, create, and edit .txt files
to create a system where a multiple choice test can be created an taken and provide a report card.""")
input("\nPress Enter to continue...")

print("""\n\n"Shmup" is a shoot 'em up game created using pygame and
includes visuals, sound, and object oriented programming.""")
input("\nPress Enter to continue...")

print("""\n\n"Tkinter Layouts" is a folder containing GUI's
using the tkinter library.""")
input("\nPress Enter to continue...")

print("""\n\n"Login System" is a practical use of the tkinter library
and is a login screen.""")
input("\nPress Enter to continue...")

print("""\n\n"Tic-Tac-Toe" is a game of tic-tac-toe that allows the player
to play against an AI.""")
input("\nPress Enter to continue...")

print("""\n\nFeel free to contact me at luke.rowberry@tooeleschools.org or #435-882-4191""")
